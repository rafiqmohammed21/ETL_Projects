/**
 * 
 */
package com.verisk.statimpl.exception;

/**
 * @author I58479
 *
 */
public class APIException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3730866214956248188L;
	
	public APIException() {
		super();
	}
	
	public APIException(String ex) {
		super(ex);
	}
	
	public APIException(Throwable ex) {
		super(ex);
	}

}
