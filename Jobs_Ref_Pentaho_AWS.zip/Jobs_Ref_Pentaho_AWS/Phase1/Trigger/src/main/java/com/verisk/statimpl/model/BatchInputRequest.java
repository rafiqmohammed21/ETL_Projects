/**
 * 
 */
package com.verisk.statimpl.model;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * @author I58479
 *
 */
public class BatchInputRequest implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3709072805769604598L;
	private String jobName;
	private String jobQueue;
	private String jobDefinition;
	private String revision;
	private Map<String, String> envOverrides;
	private List<String> commandOverrides;
	
	/**
	 * @return the jobName
	 */
	public String getJobName() {
		return jobName;
	}
	/**
	 * @param jobName the jobName to set
	 */
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	/**
	 * @return the jobQueue
	 */
	public String getJobQueue() {
		return jobQueue;
	}
	/**
	 * @param jobQueue the jobQueue to set
	 */
	public void setJobQueue(String jobQueue) {
		this.jobQueue = jobQueue;
	}
	/**
	 * @return the jobDefinition
	 */
	public String getJobDefinition() {
		return jobDefinition;
	}
	/**
	 * @param jobDefinition the jobDefinition to set
	 */
	public void setJobDefinition(String jobDefinition) {
		this.jobDefinition = jobDefinition;
	}
	/**
	 * @return the revision
	 */
	public String getRevision() {
		return revision;
	}
	/**
	 * @param revision the revision to set
	 */
	public void setRevision(String revision) {
		this.revision = revision;
	}
	/**
	 * @return the envOverrides
	 */
	public Map<String, String> getEnvOverrides() {
		return envOverrides;
	}
	/**
	 * @param envOverrides the envOverrides to set
	 */
	public void setEnvOverrides(Map<String, String> envOverrides) {
		this.envOverrides = envOverrides;
	}
	/**
	 * @return the commandOverrides
	 */
	public List<String> getCommandOverrides() {
		return commandOverrides;
	}
	/**
	 * @param commandOverrides the commandOverrides to set
	 */
	public void setCommandOverrides(List<String> commandOverrides) {
		this.commandOverrides = commandOverrides;
	}
	
	
}
