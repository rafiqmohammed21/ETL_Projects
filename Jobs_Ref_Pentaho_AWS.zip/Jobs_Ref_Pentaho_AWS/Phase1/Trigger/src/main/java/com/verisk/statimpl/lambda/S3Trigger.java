package com.verisk.statimpl.lambda;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.MimeMessage;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.S3Event;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.google.gson.Gson;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.ClientResponse.Status;
import com.verisk.statimpl.exception.APIException;
import com.verisk.statimpl.model.BatchInputRequest;

public class S3Trigger implements RequestHandler<S3Event, String> {

    private AmazonS3 s3;
    
    private String destinationBucket;
    private String batchAPI;
    private String jobDefinition;
    private String jobQueue;
    private String region;
    private Gson gson;
    private String emailFrom;
    private String emailTo;
    private String emailHost;
    
    
    private LambdaLogger logger;

    public S3Trigger() throws IOException {
    	loadEnvProperties();
    	this.gson = new Gson();
    	this.s3 = AmazonS3ClientBuilder.standard()
    			.withRegion(System.getenv("AWS_DEFAULT_REGION")).build();
    }

    // Test purpose only.
    S3Trigger(AmazonS3 s3) {
        this.s3 = s3;
    }

    @Override
    public String handleRequest(S3Event event, Context context) {
    	logger = context.getLogger();
    	String bucket = event.getRecords().get(0).getS3().getBucket().getName();
        String key = event.getRecords().get(0).getS3().getObject().getKey();
        
    	try {
	    	String sourceKey = URLDecoder.decode(key, "UTF-8");
	    	String[] splitKey = sourceKey.split("/");
	    	String filename = splitKey[splitKey.length-1];
	        logger.log("Step 1: Copying input file to destination bucket\n");
	        s3.copyObject(bucket, sourceKey, bucket, "data/"+filename);
	        
	        logger.log("Step 2: Delete input file from source bucket\n");
	        s3.deleteObject(bucket, sourceKey);
	        
	        logger.log("Step 3: Invoke batch\n");
	        invokeBatch(filename);
	        
	        return "Success";
    	}catch (Exception e) {
    		logger.log("Error Occured for file trigger: "+ key);
    		sendEmail("Error Occured for lambda file trigger: "+ key, "STaT-Implementation Lambda failure - "+this.region);
    		return "Failure";
		}
   
    }
    
    private void invokeBatch(String filename) throws APIException, InterruptedException {
    	String jobName = "STAT_IMPL_ETL_JOB";
		Map<String, String> envOverrides = new HashMap<String, String>();
		String kitchenCommand = "-file=/data/public/STAT_Project/ALLIANZ/IDP_COMMON/job_idp_load_wrapper.kjb "
				+ "-level=Basic -param:IDP_REQUEST_FILE_NM="+filename;
		envOverrides.put("kitchen_command", kitchenCommand);
		envOverrides.put("log_file", "StatDPP.Implementation/"+this.region+"/"+filename);
		logger.log("Invoking batch API with kitchen command: "+ kitchenCommand);
		invokeBatchAPI(jobName, envOverrides);
		
	}
    
   
    private void invokeBatchAPI(String jobName, Map<String, String> envOverrides) 
    		throws APIException, InterruptedException {
    	Client apiClient = Client.create();
    	WebResource webResource = apiClient.resource(this.batchAPI);
    	BatchInputRequest request = new BatchInputRequest();
    	request.setJobDefinition(this.jobDefinition);
    	request.setJobQueue(this.jobQueue);
    	request.setJobName(jobName);
    	if(envOverrides !=null ) {
    		request.setEnvOverrides(envOverrides);
    	}
    	int counter = 0;
    	boolean retry = true;
    	String output="";
    	while(retry) {
    		logger.log("\t\tCalling API to add invoke batch step");
    		ClientResponse response = webResource.accept("application/json")
    				.header("Content-Type","application/json")
    				.post(ClientResponse.class, gson.toJson(request));
        	
        	output = response.getEntity(String.class);
        	logger.log("\t\tAPI response : "+ output);
    		if(response.getClientResponseStatus().equals(Status.OK)) {
    			retry = false;
    		}else {
    			logger.log("\t\tAPI call was not successful.");
    			counter++;
    			if(counter > 5) {
    				logger.log("\t\tExceeded the number of retry attempts");
    				throw new APIException("Unable to invoke AWS batch via API. Output message: "+output);
    			}
    			logger.log("\t\tSleeping for 5secs");
    			Thread.sleep(5000);
    			
    		}
    	}
    	
    
    }

	private void loadEnvProperties() throws IOException {
		Properties prop = new Properties();
    	InputStream propertyFileInput = null;
    	try {
    		String env = System.getenv("Env");
    		if(env !=null && env.equals("D")){
    			propertyFileInput  = new FileInputStream("application-d.properties");
    		}else {
    			propertyFileInput  = new FileInputStream("application.properties");
    		}
    		prop.load(propertyFileInput);
    		this.region = prop.getProperty("region");
    		this.batchAPI = prop.getProperty("batchAPI");
    		this.jobDefinition = prop.getProperty("jobDefinition");
    		this.jobQueue = prop.getProperty("jobQueue");
    		this.emailFrom = prop.getProperty("emailFrom");
    		this.emailHost = prop.getProperty("emailHost");
    		this.emailTo = prop.getProperty("emailTo");
    	}finally {
			propertyFileInput.close();
		}
	}
	
	private void sendEmail(String body, String subject){
		try {
			Properties properties = System.getProperties();
			properties.setProperty("mail.smtp.host", this.emailHost);
			Session session = Session.getDefaultInstance(properties);
	
			MimeMessage message = new MimeMessage(session);
			message.setFrom(this.emailFrom);
			message.setSubject(subject);
			message.addRecipients(Message.RecipientType.TO, this.emailTo); // comma seperated mulitple recipients
			message.setText(body);
	
			Transport.send(message);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}