#!/bin/bash
# create and populate local directories
aws-encryption-cli --decrypt --suffix --input /app/IDP.properties --encryption-context purpose=$aws_encryption_purpose -S --output /pentaho-di/.kettle/
aws-encryption-cli --decrypt --suffix --input /app/kettle.properties --encryption-context purpose=$aws_encryption_purpose -S --output /pentaho-di/.kettle/
aws-encryption-cli --decrypt --suffix --input /app/repositories.xml --encryption-context purpose=$aws_encryption_purpose -S --output /pentaho-di/.kettle/

# create and mount s3 bucket directories
mkdir -p /data/datastore /data/distribution 
/usr/local/bin/s3fs statfiling-datastore-test /data/datastore $s3_mount_options
/usr/local/bin/s3fs statfiling-distribution-test /data/distribution $s3_mount_options

#aws s3 sync s3://statfiling-datastore-test  /data_phase2/datastore

#set logfile
MYLOGFILE=/data/logs/${log_file}-${date}.log

# capture to logfile and tee 
exec &> >( tee $MYLOGFILE )

/opt/pentaho-di/data-integration/kitchen.sh ${kitchen_command}

exitStatus=$?
echo 'Pentaho output status ' $exitStatus

#Check the output status of pentaho job
if [ $exitStatus -ne 0 ]
then
	echo 'Error occured in Pentaho job... force existing batch'		
	exit $exitStatus
fi

exit 0

