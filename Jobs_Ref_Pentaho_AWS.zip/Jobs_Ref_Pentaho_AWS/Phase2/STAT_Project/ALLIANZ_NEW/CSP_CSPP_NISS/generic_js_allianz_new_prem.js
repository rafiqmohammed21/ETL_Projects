//company_number -POS 1-4
function company_number(allianz_code)
{
	var company_number;
	if(allianz_code=="US0075")
		company_number="2058";
	else
		company_number="    ";
	
	return company_number;
}

//transaction_type_code-POS 5

function transaction_type_code()
{
	var transaction_type_code="1";
	return transaction_type_code;
}
	
//Account Date-POS 6-7

function account_date(accounting_date)
{
	if(accounting_date!= null)
	{
	var account_mm=accounting_date.substr(4,2);
	var account_yy=accounting_date.substr(3,1);
	var account_date;
	
	if(account_mm=="01" || account_mm=="02" || account_mm=="03")
		new_month="3";
	else if(account_mm=="04" || account_mm=="05" || account_mm=="06")
		new_month="6";
	else if(account_mm=="07" || account_mm=="08" || account_mm=="09")
		new_month="9";
	else  if(account_mm=="10" || account_mm=="11" || account_mm=="12")
		new_month="&";
	else 
		new_month=" ";
	
	account_date=new_month.concat(account_yy);
	}
	else
		account_date="  ";
	return account_date;
}

//Inception Date-POS 8-10

function inception_date(policy_inception_date)
{
	var inception_mm=policy_inception_date.substr(4,2);
	var inception_yy=policy_inception_date.substr(2,2);
	var inception_date;
	var new_month=replace(inception_mm,"01","1","02","2","03","3","04","4","05","5","06","6","07","7","08","8","09","9","10","0","11","-","12","&");
	
	inception_date=new_month.concat(inception_yy);
	
	return inception_date;
}

//Transaction Effective Date-POS 11-13

function transaction_effective_date(transaction_effective_date)
{
	if(transaction_effective_date !=null)
	{
	var transaction_mm=transaction_effective_date.substr(4,2);
	var transaction_yy=transaction_effective_date.substr(2,2);
	var transaction_eff_date;
	var new_month=replace(transaction_mm,"01","1","02","2","03","3","04","4","05","5","06","6","07","7","08","8","09","9","10","0","11","-","12","&");
	
	transaction_eff_date=new_month.concat(transaction_yy);
	}
	else 
		transaction_eff_date="   ";
		
	return transaction_eff_date;
}
//Transaction Expiration Date-POS 14-16

function transaction_expiration_date(transaction_expiration_date)
{
	if(transaction_expiration_date !=null)
	{
	var transaction_mm=transaction_expiration_date.substr(4,2);
	var transaction_yy=transaction_expiration_date.substr(2,2);
	var transaction_exp_date;
	var new_month=replace(transaction_mm,"01","1","02","2","03","3","04","4","05","5","06","6","07","7","08","8","09","9","10","0","11","-","12","&");
	
	transaction_exp_date=new_month.concat(transaction_yy);
	}
	else
		transaction_exp_date="   ";
	
	return transaction_exp_date;
}

//state code-POS 17-18

function state_code(code)
{
var state_cd =replace(code,'AL','01','AZ','02','AR','03','CA','04','CO','05','CT','06','DE','07','DC','08','FL','09','GA','10','ID','11','IL','12','IN','13',
						   'IA','14','KS','15','KY','16','LA','17','ME','18','MD','19','MA','20','MI','21','MN','22','MS','23','MO','24','MT','25','NE','26', 
						   'NV','27','NH','28','NJ','29','NM','30','NY','31','NC','32','ND','33', 'OH','34','OK','35','OR','36','PA','37','RI','38','SC','39',
						   'SD','40','TN','41','TX','42','UT','43','VT','44','VA','45','WA','46','WV','47','WI','48','WY','49','HI','52','AK','54','AA','61',
						   'BC','62','MB','63', 'NB','71','NF','65','NS','72','NW','69','ON','64','PE','60','PQ','66', 'PR','58','SS','67','YU','68');
return state_cd;
}

//Territory Code-POS 19-21
/*function territory_code(ssub_line,)
{
	
	
	
	
	//need to get the logic
	
	
	
	
	
}*/

function rule_9(amount,pos)
{
var alpha_dict={
'0':['{','}'],
'1':['A','J'],
'2':['B','K'],
'3':['C','L'],
'4':['D','M'],
'5':['E','N'],
'6':['F','O'],
'7':['G','P'],
'8':['H','Q'],
'9':['I','R']
};
var act_amount=amount.toString();
if(amount != null && amount>=1)
{
	var lastChar;//flag =0;
	amount = Math.round(amount).toString();
	amount = lpad(amount,'0',pos);
	if(act_amount.indexOf('-')>-1)
		{ //flag = 1;
			lastChar = alpha_dict[amount.slice(-1)][1];
		} 
	else
		{
			lastChar = alpha_dict[amount.slice(-1)][0];
		}
	amount = Math.abs(Math.round(act_amount)).toString().slice(0,-1);
	amount = amount + lastChar;
	amount = lpad(amount,'0',pos); 
return amount;
}
else if(amount<1 && amount >=0)
{
	var lastChar;//flag =0;
	amount = Math.ceil(amount).toString();
	amount = lpad(amount,'0',pos);
	if(act_amount.indexOf('-')>-1)
		{ //flag = 1;
			lastChar = alpha_dict[amount.slice(-1)][1];
		} 
	else
		{
			lastChar = alpha_dict[amount.slice(-1)][0];
		}
	amount = Math.abs(Math.round(act_amount)).toString().slice(0,-1);
	amount = amount + lastChar;
	amount = lpad(amount,'0',pos); 
return amount;
	
}
else if(amount>-1 && amount<0)
{
	var lastChar;//flag =0;
	amount = Math.floor(amount).toString();
	amount = lpad(amount,'0',pos);
	if(act_amount.indexOf('-')>-1)
		{ //flag = 1;
			lastChar = alpha_dict[amount.slice(-1)][1];
		} 
	else
		{
			lastChar = alpha_dict[amount.slice(-1)][0];
		}
	amount = Math.abs(Math.round(act_amount)).toString().slice(0,-1);
	amount = amount + lastChar;
	amount = lpad(amount,'0',pos); 
return amount;
}
else if(amount<=-1)
{
	var lastChar;//flag =0;
	amount = Math.ceil(amount).toString();
	amount = lpad(amount,'0',pos);
	if(act_amount.indexOf('-')>-1)
		{ //flag = 1;
			lastChar = alpha_dict[amount.slice(-1)][1];
		} 
	else
		{
			lastChar = alpha_dict[amount.slice(-1)][0];
		}
	amount = Math.abs(Math.round(act_amount)).toString().slice(0,-1);
	amount = amount + lastChar;
	amount = lpad(amount,'0',pos); 
return amount;
	
}

}
